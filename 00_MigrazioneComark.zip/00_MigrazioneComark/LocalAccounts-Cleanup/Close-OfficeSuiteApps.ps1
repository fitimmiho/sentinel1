﻿# Close all Office Apps
Get-Process | Where-Object { $_.Description -like "*Office Click*" -or $_.Description -like "*Access*" -or $_.Description -like "*OneNote*" -or $_.Description -like "*Word*" -or $_.Description -like "*Outlook*" -or $_.Description -like "*Excel*" -or $_.Description -like "*Teams*" -or $_.Description -like "*OneDrive*" -or $_.Description -like "*SharePoint*" -or $_.Description -like "*PowerPoint*" } | Stop-Process -Force -Confirm:$False

# Clear Outlook Profiles for All Users
$domArr = @(
    "*comark.it*",
    "*comark.digital*",
    "*comark.es*",
    "*comarknetwork.it*",
    "*comarksl.es*",
    "*comarkspa.it*",
    "*queryo.com*"
)

$userProfiles = Get-ChildItem -Path "C:\Users" -Exclude "Public" -ErrorAction SilentlyContinue
foreach ($profile in $userProfiles){
    $confFilesPath = "C:\Users\$($profile.Name)\Appdata\Local\Microsoft\Outlook\16"
    foreach ($domain in $domArr){
        $confFiles = $null
        $confFiles = Get-ChildItem -Path  $confFilesPath -Hidden -ErrorAction SilentlyContinue | Where-Object {$_.Name -like $domain}
        if ($confFiles){
            foreach ($file in $confFiles){
                $file | Remove-Item -Confirm:$false -Force
            }
        }
    }
}

# Clear the Registry Keys related to Identities
$regUsers = Get-ChildItem Registry::HKEY_USERS\ | Where-Object {$_.Name -notlike "*Classes*"}
foreach ($regUser in $regUsers){
    $regPath = "$($regUser.Name)\SOFTWARE\Microsoft\Office\16.0\Common\Identity\Identities\"

    $regIdentities = Get-ChildItem Registry::$regPath -ErrorAction SilentlyContinue | Get-ItemProperty -name 'EmailAddress'

    foreach ($ID in $regIdentities) {
        foreach ($dom in $domArr){
            if ($ID.EmailAddress -like $dom){
                Write-Host "ID $($ID.EmailAddress) - $($dom)"
                Remove-Item $ID.PSPath -Recurse -Force
            }
        }
    }
}

# Clear Current User Registration Status
Get-ItemProperty -Path "C:\Users\*\AppData\Local\Packages" -ErrorAction SilentlyContinue | ForEach-Object {
	Remove-Item -Path "$_\Microsoft.AAD.BrokerPlugin*" -Recurse -Force | Out-Null
}
