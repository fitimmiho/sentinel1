﻿# Define Environmental Variables
$FilePath_Outlook = "$($env:USERPROFILE)\appdata\local\Packages\Microsoft.OutlookForWindows_8wekyb3d8bbwe\LocalCache"

# Get Teams Process and Stop it
Get-Process | Where-Object {$_.Description -like "*Outlook*"} | Stop-Process -Force -Confirm:$False -ErrorAction SilentlyContinue

# Clear Teams Cache
Remove-Item $FilePath_Outlook -Recurse -Include *.* -Confirm:$False -ErrorAction SilentlyContinue
