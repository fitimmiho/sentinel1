﻿# Define Environmental Variables
$FilePath_OneAuth = "$($env:LOCALAPPDATA)\Microsoft\OneAuth"
$FilePath_IdentityCache = "$($env:LOCALAPPDATA)\Microsoft\IdentityCache"

# Clear Auth Cache
Remove-Item $FilePath_OneAuth -Recurse -Confirm:$False
Remove-Item $FilePath_IdentityCache -Recurse -Confirm:$False

# Clear Current User Registration Status
Get-ItemProperty -Path "C:\Users\*\AppData\Local\Packages" -ErrorAction SilentlyContinue | ForEach-Object {
	Remove-Item -Path "$_\Microsoft.AAD.BrokerPlugin*" -Recurse -Force | Out-Null
}