﻿# Define Environmental Variables
$FilePath_Teams = "$($env:USERPROFILE)\appdata\local\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams"

# Get Teams Process and Stop it
Get-Process | Where-Object {$_.Description -like "*Teams*"} | Stop-Process -Force -Confirm:$False -ErrorAction SilentlyContinue

# Clear Teams Cache
Remove-Item $FilePath_Teams -Recurse -Include *.* -Confirm:$False -ErrorAction SilentlyContinue
