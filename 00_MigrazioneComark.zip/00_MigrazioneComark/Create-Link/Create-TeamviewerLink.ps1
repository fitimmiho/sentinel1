$linkPath = Join-Path ([Environment]::GetFolderPath("CommonDesktopDirectory")) "COMARK-Migration\TeamviewerQS.lnk"
$targetPath = Join-Path ([Environment]::GetFolderPath("CommonApplicationData")) "00_MigrazioneComark\TeamViewerQS_x64.exe"
$link = (New-Object -ComObject WScript.Shell).CreateShortcut( $linkpath )
$link.TargetPath = $targetPath
$link.Save()